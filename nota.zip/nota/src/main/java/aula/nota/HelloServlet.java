package aula.nota;

import java.io.*;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "helloServlet", value = "/nota")
public class HelloServlet extends HttpServlet {
    private String message;

    public void init() {
        message = "Hello World!";
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        double nota = 0.0;

        String nomeAluno = request.getParameter("nomeAluno");
        String[] animais = request.getParameterValues("opera");
        String ch1 = request.getParameter("ch1");//sim
        String ch2 = request.getParameter("ch2");//nao
        String ch3 = request.getParameter("ch3");//nao
        String ch4 = request.getParameter("ch4");//sim
        String ch5 = request.getParameter("ch5");//sim

        String data = request.getParameter("guerra");//ok

        String rad1 = request.getParameter("metal");

        int expres = Integer.parseInt(request.getParameter("expres"));//ok

        if (expres == 19) {
            nota = nota + 2;
        }


        if (data.equals("1914-07-28")) {
            nota = nota + 2;
        } else nota = nota - 2;

        if (ch1 != null) {//sistema operacional
            nota = nota + 0.4;
        } else nota = nota - 0.4;

        if (ch2 != null) {//"Memôria RAM"
            nota = nota - 0.4;
        } else nota = nota + 0.4;

        if (ch3 != null) {//"gpu"
            nota = nota - 0.4;
        } else nota = nota + 0.4;

        if (ch4 != null) {//"Planilha
            nota = nota + 0.4;
        } else nota = nota - 0.4;

        if (ch5 != null) {//"compilador
            nota = nota + 0.4;
        } else nota = nota - 0.4;


        if (rad1 != null && rad1.equals("Mercurio")) {
            nota = nota + 2.0;
        } else nota = nota - 2.0;


        for (String an : animais) {
            if (an.equalsIgnoreCase("Golfinho") || an.equalsIgnoreCase("Onca") ||
                    an.equalsIgnoreCase("MicoLeao")) {
                nota = nota + 0.666667;
            } else nota = nota - 0.4;
        }


        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        if (nota > 6.001) {
            out.printf("<h1> Aluno&#40;a&#41;: %s Aprovado&#40;a&#41;, Nota %.2f!</h1>",nomeAluno,  nota);

        } else out.printf("<h1> Aluno&#40;a&#41;: %s Reprovado&#40;a&#41;, Nota %.2f!</h1>", nomeAluno, nota);
        out.println("</body></html>");
    }

    public void destroy() {
    }
}